import json
import os
import faiss
import numpy as np
import torch
import torch.nn as nn
from transformers import AutoModel, AutoTokenizer
from typing import List, Dict, Tuple
from tqdm import tqdm

class MultilingualRetriever:
    def __init__(self, model_paths: Dict[str, str], langs: List[str]):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.langs = langs
        self.models = {}
        self.tokenizers = {}
        
        # Load models for each language
        for model_name, path in model_paths.items():
            model_path = f"/PLM/"
            print(f"Loading {model_name} from {model_path}...")
            self.models[model_name] = AutoModel.from_pretrained(model_path).to(self.device)
            self.tokenizers[model_name] = AutoTokenizer.from_pretrained(model_path)
    
    def encode_batch(self, texts: List[str], model_name: str) -> np.ndarray:
        tokenizer = self.tokenizers[model_name]
        model = self.models[model_name]
        
        inputs = tokenizer(texts, return_tensors='pt', padding=True, truncation=True, max_length=512).to(self.device)
        with torch.no_grad():
            outputs = model(**inputs)
        return outputs.last_hidden_state[:, 0, :].cpu().numpy()  # CLS token

    def build_faiss_index(self, corpus_embeddings: np.ndarray) -> faiss.Index:
        """Build a FAISS index for efficient retrieval"""
        dim = corpus_embeddings.shape[1]
        index = faiss.IndexFlatIP(dim)  # Inner product (cosine similarity)
        faiss.normalize_L2(corpus_embeddings)  # Normalize for cosine similarity
        index.add(corpus_embeddings)
        return index

class LinguisticExpertSystem(nn.Module):
    def __init__(self, model_names: List[str], unified_dim: int = 512):
        super().__init__()
        # Load multiple multilingual retrieval models
        self.models = nn.ModuleDict({
            name: AutoModel.from_pretrained(name) 
            for name in model_names
        })
        
        # Initialize learnable linear transformation layers
        self.projection_layers = nn.ModuleDict({
            name: nn.Linear(model.config.hidden_size, unified_dim)
            for name, model in self.models.items()
        })
        
        # Attention weight calculation layer
        self.attention = nn.MultiheadAttention(unified_dim, num_heads=8)

    def encode(self, texts: List[str], tokenizer: AutoTokenizer) -> Dict[str, torch.Tensor]:
        """Multi-model encoding"""
        inputs = tokenizer(texts, return_tensors='pt', padding=True, truncation=True)
        return {
            name: model(**inputs).last_hidden_state[:,0,:]  # Take CLS token
            for name, model in self.models.items()
        }

    def dynamic_fusion(self, query_reps: Dict[str, torch.Tensor], doc_reps: Dict[str, torch.Tensor]) -> torch.Tensor:
        """Dynamic feature fusion"""
        # Linear projection to unified dimension
        query_proj = [self.projection_layers[name](rep) for name, rep in query_reps.items()]
        doc_proj = [self.projection_layers[name](rep) for name, rep in doc_reps.items()]
        
        # Concatenate multi-model representations [num_models, batch_size, unified_dim]
        combined_query = torch.stack(query_proj, dim=0)
        combined_doc = torch.stack(doc_proj, dim=0)
        
        # Attention fusion
        attn_output, _ = self.attention(combined_query, combined_doc, combined_doc)
        return attn_output.mean(dim=0)  # Average to get final representation

class HardNegativeMiner:
    def __init__(self, model_paths: Dict[str, str], langs: List[str]):
        self.retriever = MultilingualRetriever(model_paths, langs)
        self.langs = langs
        # Initialize LinguisticExpertSystem
        self.expert_system = LinguisticExpertSystem(
            model_names=["BAAI/bge-m3", "intfloat/multilingual-e5-large"],
            unified_dim=768
        ).to(self.retriever.device)
    
    def process_language(self, lang: str):
        """Process queries and corpus for one language"""
        # Load queries
        query_path = f"/Data/miracl/query/{lang}.jsonl"
        queries = []
        with open(query_path, 'r', encoding='utf-8') as f:
            for line in f:
                data = json.loads(line)
                queries.append((data['id'], data['query'], data.get('positives', [])))
        
        # Load corpus
        corpus_path = f"/Data/miracl/corpus/{lang}.jsonl"
        corpus = []
        with open(corpus_path, 'r', encoding='utf-8') as f:
            for line in f:
                data = json.loads(line)
                corpus.append((data['docid'], data['text']))
        
        # Encode corpus using LinguisticExpertSystem
        print(f"Encoding {lang} corpus with LinguisticExpertSystem...")
        corpus_texts = [text for _, text in corpus]
        corpus_reps = self.retriever.encode_batch(corpus_texts, 'BGE')
        corpus_reps = torch.from_numpy(corpus_reps).to(self.retriever.device)
        
        # Use LinguisticExpertSystem for dynamic fusion
        corpus_reps_dict = self.expert_system.encode(corpus_texts, self.retriever.tokenizers['BGE'])
        corpus_fused = self.expert_system.dynamic_fusion(corpus_reps_dict, corpus_reps_dict)
        corpus_fused = corpus_fused.cpu().numpy()
        
        # Build FAISS index
        index = self.retriever.build_faiss_index(corpus_fused)
        
        # Process queries
        output_path = f"/Data/miracl/negatives/{lang}.jsonl"
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        
        with open(output_path, 'w', encoding='utf-8') as outfile:
            for qid, query, positives in tqdm(queries, desc=f"Processing {lang} queries"):
                # Encode query using LinguisticExpertSystem
                query_reps_dict = self.expert_system.encode([query], self.retriever.tokenizers['BGE'])
                query_fused = self.expert_system.dynamic_fusion(query_reps_dict, query_reps_dict)
                query_fused = query_fused.cpu().numpy()
                faiss.normalize_L2(query_fused)
                
                # Search top 40 documents 
                _, indices = index.search(query_fused, k=41)
                
                # Filter out positive documents
                filtered_indices = [idx for idx in indices[0][1:] if idx not in positives]
                
                
                negatives = [corpus[idx][1] for idx in filtered_indices]
                
                # Save results including the positives field
                result = {
                    "id": qid,
                    "query": query,
                    "positives": positives,  
                    "negatives": negatives
                }
                outfile.write(json.dumps(result, ensure_ascii=False) + '\n')
    
    def run(self):
        """Process all languages"""
        for lang in self.langs:
            self.process_language(lang)

if __name__ == "__main__":
    # Configuration
    model_paths = {
        "BGE": "BAAI/bge-m3",
        "mE5": "intfloat/multilingual-e5-large"
    }
    langs = ['ar', 'bn', 'en', 'es', 'fa', 'fi', 'fr', 'hi', 'id', 'ja', 'ko', 'ru', 'sw', 'te', 'th', 'zh']
    
    # Run mining process
    miner = HardNegativeMiner(model_paths, langs)
    miner.run()