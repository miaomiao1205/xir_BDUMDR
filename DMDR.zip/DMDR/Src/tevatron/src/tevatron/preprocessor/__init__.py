from .preprocessor_tsv import SimpleTrainPreProcessor as MarcoPassageTrainPreProcessor,  \
    SimpleCollectionPreProcessor as MarcoPassageCollectionPreProcessor
