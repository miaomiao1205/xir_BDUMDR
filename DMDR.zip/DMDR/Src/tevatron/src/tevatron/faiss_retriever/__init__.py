from .retriever import BaseFaissIPRetriever
